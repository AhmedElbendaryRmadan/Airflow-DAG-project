from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.bash_operator import BashOperator 
from airflow.operators.python import PythonOperator
import random

# Task 2: دالة لطباعة رسالة ترحيب
def print_welcome():
    print("Welcome Ahmed Elbendary")
    
# الدالة لتوليد رقم عشوائي وحفظه    
def generate_random():
    random_num = random.randint(1, 1000)
    with open('/opt/airflow/shared/random.txt', 'w') as file:
        file.write(str(random_num))
    print(f"Generated random number: {random_num} and saved to random.txt")



with DAG(
     dag_id = "Airflow_Depi",
     start_date = datetime(2025, 10, 2),
     schedule_interval = timedelta(minutes = 1),
     catchup = False
) as dag:
    
    task_date = BashOperator(
        task_id = "print_date",
        bash_command = 'date'
    )

    task_welcome = PythonOperator(
        task_id = "welcome_message",
        python_callable = print_welcome
    )

    task_random = PythonOperator(
        task_id ="generate_random",
        python_callable = generate_random
    )

    task_date >> task_welcome >> task_random

