from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
import sqlite3

def show_student():
    conn = sqlite3.connect("/opt/airflow/shared/mansoura_depi.db")
    cursor = conn.cursor()

    cursor.execute("select * from student")

    data = cursor.fetchall()
    
    for i in data:
        print(i)

    cursor.close()
    conn.close()

with DAG (
    dag_id = "dag3",
    start_date = datetime(2025, 10, 2),
    schedule_interval = timedelta(minutes= 1),
    catchup = False
) as dag :
    task_sqlite = PythonOperator(
        task_id = "task_sqlite",
        python_callable = show_student
    )